use digest::Digest;
use sha2::Sha256;

// Define a Merkle tree node
#[derive(Debug, Clone)]
struct MerkleNode {
    hash: String,
    left: Option<Box<MerkleNode>>,
    right: Option<Box<MerkleNode>>,
}

// Merkle tree structure
#[derive(Debug, Clone)]
struct MerkleTree {
    root: Option<Box<MerkleNode>>,
}

// Merkle proof structure
#[derive(Debug, Clone)]
struct MerkleProof {
    path: Vec<(String, bool)>, // (hash, is_left)
}

// Helper function to calculate SHA256 hash of a string
fn sha256_hash(data: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(data.as_bytes());
    hasher.finalize().as_slice().to_vec().iter().map(|&byte| format!("{:02x}", byte)).collect()
}

// Function to build a Merkle tree from a list of data items
fn build_merkle_tree(data: Vec<&str>) -> MerkleTree {
    let mut leaves: Vec<MerkleNode> = data
        .iter()
        .map(|&item| MerkleNode {
            hash: sha256_hash(item),
            left: None,
            right: None,
        })
        .collect();

    while leaves.len() > 1 {
        let mut parents = Vec::new();

        for chunk in leaves.chunks_exact(2) {
            let mut hasher = Sha256::new();
            hasher.update(chunk[0].hash.as_bytes());
            hasher.update(chunk[1].hash.as_bytes());
            let parent_hash = hasher.finalize().as_slice().to_vec().iter().map(|&byte| format!("{:02x}", byte)).collect();

            let parent_node = MerkleNode {
                hash: parent_hash,
                left: Some(Box::new(chunk[0].clone())),
                right: Some(Box::new(chunk[1].clone())),
            };

            parents.push(parent_node);
        }

        leaves = parents;
    }

    MerkleTree {
        root: leaves.pop().map(Box::new),
    }
}

// Function to generate a Merkle proof for a data item
fn generate_merkle_proof(tree: &MerkleTree, target: &str) -> Option<MerkleProof> {
    fn recursive_generate_proof(node: &MerkleNode, target: &str) -> Option<MerkleProof> {
        println!("Checking node with hash: {}", node.hash);
        if node.hash == sha256_hash(target) {
            println!("Target found in leaf node");
            return Some(MerkleProof { path: vec![] });
        }

        if node.left.is_none() || node.right.is_none() {
            // Leaf node reached, target not found
            println!("Reached leaf node without finding the target");
            return None;
        }

        if let Some(left) = &node.left {
            if let Some(mut proof) = recursive_generate_proof(left, target) {
                proof.path.push((node.right.as_ref().unwrap().hash.clone(), false));
                return Some(proof);
            }
        }

        if let Some(right) = &node.right {
            if let Some(mut proof) = recursive_generate_proof(right, target) {
                proof.path.push((node.left.as_ref().unwrap().hash.clone(), true));
                return Some(proof);
            }
        }

        None
    }

    if let Some(root) = &tree.root {
        recursive_generate_proof(root, target)
    } else {
        None
    }
}
fn main() {
    // Example usage
    let data_items = vec!["item1", "item2", "item3", "item4"];
    let merkle_tree = build_merkle_tree(data_items.clone());
    println!("\n");

    println!("\n Merkle Tree: {:?}", merkle_tree);
    println!("\n");

    let target_item = "item3";
    if let Some(merkle_proof) = generate_merkle_proof(&merkle_tree, target_item) {
        println!("Merkle Proof for {}: {:?}", target_item, merkle_proof);
    } else {
        println!("Item {} not found in the Merkle tree", target_item);
    }
}